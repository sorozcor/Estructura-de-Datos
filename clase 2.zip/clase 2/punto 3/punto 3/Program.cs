﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace punto_3
{
    class Program
    {
        //Se trata de escribir el algoritmo que permita emitir la factura correspondiente a una compra de un
        // artículo determinado del que se adquieren una o varias unidades.El IVA a aplicar es del 11.5% y si
       //el precio bruto (precio de venta más IVA) es mayor de 500 Bs.F., se aplicará un descuento del 6.5%
      
        static void Main(string[] args)
        {
            double u, c, pb,vc,f=0;
           
            string v="";
            Console.WriteLine("Ingrese las unidades del producto");
            v = Console.ReadLine();
            u = Convert.ToInt32(v);
            Console.WriteLine("Ingrese el valor del producto");
            v = Console.ReadLine();
            c = Convert.ToInt32(v);

            vc = c * u;
            pb = vc + (vc * 0.115);

            if (pb >= 500)
            {
                f = pb - (pb * 0.065);
                Console.WriteLine("El valor total del producto es:{0} ", f);

            }
            else
                Console.WriteLine("El valor total del producto es:{0} ", f);
        }
    }
}
