﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;

namespace punto_1
{
    class Program
    {
        //Escribir un algoritmo que lea cuatro números e indique cual es el mayor
        static void Main(string[] args)
        {
            int n1, n2, n3, n4;
            string v1="", v2="", v3="", v4="";

            Console.WriteLine("Ingrese el primer numero");
            v1 = Console.ReadLine();
            n1 = Convert.ToInt32(v1);
            Console.WriteLine("Ingrese el segundo numero");
            v2 = Console.ReadLine();
            n2 = Convert.ToInt32(v2);
            Console.WriteLine("Ingrese el tercer numero");
            v3 = Console.ReadLine();
            n3 = Convert.ToInt32(v3);
            Console.WriteLine("Ingrese el cuarto numero");
            v4 = Console.ReadLine();
            n4 = Convert.ToInt32(v4);

            if (n1 >= n2 && n1 >= n3 && n1 >= n4)
                Console.WriteLine("El numero mayor es: {0} ", n1);
            else
                if(n2>n3)
                Console.WriteLine("El numero mayor es: {0} ", n2);
            else 
                if(n3>n4)
                Console.WriteLine("El numero mayor es: {0}", n3);
            else
                Console.WriteLine("El numero mayor es : {0}", n4);


        }
    }
}
