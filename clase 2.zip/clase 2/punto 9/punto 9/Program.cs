﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
namespace punto_9
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, m = 0, n=9999999;
            string entrada;

            Console.WriteLine("Digite un numero distinto a cero\n\n...Cuando termine de insertar todos los numeros,\n escriba -99 para mostrar el numero mayor ingresado en pantalla");
            entrada = Console.ReadLine();
            num = Convert.ToInt32(entrada);

            while (num != -99)
            {
                Console.WriteLine("inserte otro numero distinto a cero");
                entrada = Console.ReadLine();
                num = Convert.ToInt32(entrada);

                if (num > m)
                {
                    m = num;
                }
            }

            Console.WriteLine("el numero mayor es el {0}", m);
        }
    }
}
            
