﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
namespace punto_6
{
    class Program
    {
      //  Determinar el precio de un pasaje en ferrocarril, conociendo la distancia a recorrer y sabiendo que, si
//el número de días de estancia es superior a siete y la distancia superior a 800 kilómetros, el pasaje
//tiene una reducción del 30%. El precio por kilómetro es de 2.5$. 
        static void Main(string[] args)
        {
            int dist, time;
               double costo;
            string v = "",v2="";
            Console.WriteLine("ingrese la distancia ");
            v = Console.ReadLine();
            dist = Convert.ToInt32(v);
            Console.WriteLine("ingrese el tiempo ");
            v2 = Console.ReadLine();
            time = Convert.ToInt32(v);

            if (dist > 800 && time > 7)
            {
                costo = dist * 2.5 * 0.70;
            }
            else
            
                costo = dist * 2.5;

            Console.WriteLine("el costo del billete es:{0} ");
        }
    }
}
