﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;

namespace punto_4
{
   
    class Program
    { //Para un salario base hasta de 1500$, no hay retención.Para un salario base mayor a 1500$ a 3000$ el
      //porcentaje de retención es del 5%. Para un salario base mayor de 3000$ el porcentaje de retención es
      //del 8%. Obtener la retención y el salario neto de N empleados.

        static void Main(string[] args)
        {
            double sb, r, sn = 0;
            string v = "";
            Console.WriteLine("Ingrese el salario base");
            v = Console.ReadLine();
            sb = Convert.ToInt32(v);

            if (sb <= 1500)
            {
                sn = sb;
                Console.WriteLine("el salario neto es:{0} ", sn);
                Console.WriteLine(" el salario base es menor a 1500 no hay retencion");
            }
            else if (sb > 1500 && sb <= 3000)
            {

                sn = sb - (sb * 0.05);
                Console.WriteLine("el salario neto es: {0}", sn);
                r = sb * 0.05;
                Console.WriteLine("la retencion es:{0} ", r);
            }
            else if(sb>3000)
            {
                sn = sb - (sb * 0.08);
                Console.WriteLine("el salario neto es:{0} ", sn);
                r = sb * 0.08;
                Console.WriteLine("la retencion es:{0} ", r);


            }

        }
    }
}
