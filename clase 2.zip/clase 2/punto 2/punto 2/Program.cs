﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
namespace punto_2
{
    class Program
    {
        //Diseñar un algoritmo que permita determinar si un número introducido es primo o no. Un número es
      //  primo cuando solamente es divisible entre el mismo y la unidad.
        static void Main(string[] args)
        {
            int a = 0, num;
            Console.WriteLine("INGRESE EL NUMERO");
            num = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i < (num + 1); i++)
            {
                if (num % i == 0)
                {
                    a++;
                }
            }
            if (a != 2)
            {
                Console.WriteLine(num + " No es primo");
            }
            else
            {
                Console.WriteLine(num + " Si es primo");
            }
            Console.ReadLine();
        }
    }
}
