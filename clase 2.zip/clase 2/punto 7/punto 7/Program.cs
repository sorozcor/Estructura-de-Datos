﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
namespace punto_7
{
    class Program
    {
        //Dados tres números diferentes, deducir cual es el central

        static void Main(string[] args)
        {
            int n1, n2, n3;
            string v1 = "", v2="", v3 = "";
            Console.WriteLine("ingrese numero 1");
            v1 = Console.ReadLine();
            n1 = Convert.ToInt32(v1);
            Console.WriteLine("ingrese numero 2");
            v2 = Console.ReadLine();
            n2 = Convert.ToInt32(v2);
            Console.WriteLine("ingrese numero 3");
            v3 = Console.ReadLine();
            n3 = Convert.ToInt32(v3);

            if (n1 <= n2 && n2 <= n3)
            {
                Console.WriteLine("El numero del medio es: {0}", n2);
            }
            else if (n1 <= n3 && n3 <= n2)
            {
                Console.WriteLine("El numero del medio es: {0}", n3);
            }
            else if(n2<=n1&&n1<=n3)
            {
                Console.WriteLine("El numero del medio es: {0}", n1);
            }
            else if(n2<=n3&&n3<=n1)
            {
                Console.WriteLine("El numero del medio es: {0}", n3);

            }
            else if(n3<=n1&&n1<=n2)
            {
                Console.WriteLine("El numero del medio es: {0}", n1);

            }
            else
                Console.WriteLine("El numero del medio es: {0}", n2);

        }
    }
}
