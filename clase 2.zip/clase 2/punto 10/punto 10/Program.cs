﻿using System;

namespace punto_10
{
    class Program
    {
        static void Main(string[] args)
        {
            int nume, i, edad, escvl, sx, sal, cont1 = 0, cont2 = 0, cont3 = 0, cont4 = 0;
            double edadtotalh = 0, edadpromh = 0;
            string entrada;

            Console.WriteLine("¿para cuantos empleados desea hacer las estadisticas?");
            entrada = Console.ReadLine();
            nume = Convert.ToInt32(entrada);

            for (i = 1; i <= nume; i++)
            {
                Console.WriteLine("digite la edad del empleado " + i);
                entrada = Console.ReadLine();
                edad = Convert.ToInt32(entrada);

                Console.WriteLine("indique el estado civil del empleado " + i + " donde:\n 1= soltero\n 2= casado \n 3= viudo");
                entrada = Console.ReadLine();
                escvl = Convert.ToInt32(entrada);

                Console.WriteLine("indique el sexo del empleado " + i + " donde:\n 1= femenino\n 2= masculino");
                entrada = Console.ReadLine();
                sx = Convert.ToInt32(entrada);
                if (sx == 1)
                {
                    cont1 = cont1 + 1;
                }
                if (sx == 2)
                {
                    cont2 = cont2 + 1;
                }
                if (sx == 2)
                {
                    edadtotalh = edadtotalh + edad;
                }
                Console.WriteLine("indique el rango de salario del empleado " + i + " donde:\n 1= menos de 600 Bs.F.\n 2= Entre 600 y 1000 Bs.F. \n 3= Mas de 1000Bs.F.");
                entrada = Console.ReadLine();
                sal = Convert.ToInt32(entrada);

                if (sx == 2 && escvl == 2 && sal == 3)
                {
                    cont3 = cont3 + 1;
                }
                else if (sx == 1 && escvl == 3 && sal == 2)
                {
                    cont4 = cont4 + 1;
                }

            }
            if (edadtotalh > 1)
            {
                edadpromh = edadtotalh / cont2;
            }

            Console.WriteLine("en total hay {0} empleados de sexo femenino", cont1);
            Console.WriteLine("en total hay {0} hombres casados que ganan mas de 1000Bs.F.", cont3);
            Console.WriteLine("en total hay {0} mujeres viudas que ganan mas de 600Bs.F", cont4);
            Console.WriteLine("la edad promedio de los hombres es de {0} años", edadpromh);
        }
    }
}
      