﻿using System;

using System.Collections.Generic;

using System.Text;

namespace Ejercicio_4_8

{

public class Clase

{

void ordena(int[] ar, int tam)

{// Recibe un arreglo de enteros y la organiza de menor a mayor

int i = 0, t = 0, j = 0;

for (j = 0; j < tam; j++)

{

for (i = j; i < tam; i++)

{

if (ar[i] < ar[j])

{

t = ar[j]; ar[j] = ar[i]; ar[i] = t;

}

}

}

}

public Int32 CapturaNumero(string cadena)

{

string Strnumber;

int number = 0;

try

{

Console.Write(cadena);

Strnumber = Console.ReadLine();

number = Convert.ToInt32(Strnumber);

}

catch

{

Console.WriteLine("Numero Invalido!!!");

return CapturaNumero(cadena);

}

return number;

}

public void Run()

{

int CuantosAlumnos = 0;

int [] Todos=new int[2000];

int Menos_40=0,Entre40y50=0,Mas50yMenos60=0,MasIgual60=0;

CuantosAlumnos = CapturaNumero("Cantidad de Alumnos en la Muestra ");

for (int i=0;i<CuantosAlumnos;i++){

Todos[i] = CapturaNumero("Introducir peso para alumno " + i.ToString()+": ");

}

ordena(Todos, CuantosAlumnos);

for(int i=0;i<CuantosAlumnos;i++){

if(Todos[i]<40)Menos_40++;

if(Todos[i]>=40 && Todos[i]<=50)Entre40y50++;

if(Todos[i]>50 && Todos[i]<60)Mas50yMenos60++;

if(Todos[i]>=60)MasIgual60++;

Console.Write(" {0}", Todos[i]);

}

Console.WriteLine("\n=================================================================");

Console.WriteLine("Los alumnos < a 40 son {0:##0} {1:##0.00}%", Menos_40, Menos_40 * 100 / CuantosAlumnos);

Console.WriteLine("Los alumnos > ó = a 40 y < ó = 50 son {0:##0} {1:##0.00}%", Entre40y50, Entre40y50 * 100 / CuantosAlumnos);

Console.WriteLine("Los alumnos > a 50 y < 60 son {0:##0} {1:##0.00}%", Mas50yMenos60, Mas50yMenos60 * 100 / CuantosAlumnos);

Console.WriteLine("Los alumnos > ó = a 60 son {0:##0} {1:##0.00}%", MasIgual60, MasIgual60 * 100 / CuantosAlumnos);

Console.WriteLine("El total de alumnos fueron {0:##0} {1:##0.00}%", CuantosAlumnos, CuantosAlumnos * 100 / CuantosAlumnos);

}

}

class Program

{

static void Main(string[] args)

{

Clase ejecuta = new Clase();

ejecuta.Run();

Console.ReadLine();

}

}

}