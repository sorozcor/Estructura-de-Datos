﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;

namespace punto_8
{
    
    class Program
    {
        //Diseñar un algoritmo en el que a partir de una fecha introducida por teclado con el formato DIA,
        //MES, AÑO, se obtenga la fecha del día siguiente.
        static void Main(string[] args)
        {
            int año, año_siguiente, dia, dia_siguiente, mes, mes_siguiente;

            Console.Write("Ingrese el valor de año: ");
            año = int.Parse(Console.ReadLine());
            Console.Write("Ingrese el valor de dia: ");
            dia = int.Parse(Console.ReadLine());
            Console.Write("Ingrese el valor de mes: ");
            mes = int.Parse(Console.ReadLine());
            if ((dia == 30 && (mes == 4 || mes == 6 || mes == 9 || mes == 11)) || (dia == 29 && mes == 2) || (dia == 28 && mes == 2 && ((año % 4 != 0) || (año % 100) == 0) && (año % 400) != 0) || dia == 31)
            {
                mes_siguiente = mes + 1;
                dia_siguiente = 1;
            }
            else
            {
                dia_siguiente = dia + 1;
                mes_siguiente = mes;
            }

            if (dia_siguiente == 1 && mes_siguiente == 13)
            {
                mes_siguiente = 1;
                año_siguiente = año + 1;
            }
            else
                año_siguiente = año;
            Console.WriteLine("Valor de año siguiente:{0} " , año_siguiente);
            Console.WriteLine("Valor de dia suguiente:{0} ", dia_siguiente);
            Console.WriteLine("Valor de mes siguiente:{0} ", mes_siguiente);
           
        }
    }
}
